#!/bin/bash

TOP_DIR=/opt/molchip
TOOL_DIR=$TOP_DIR/arm-molchip-linux
TAR_BIN_DIR=$TOOL_DIR/bin
PKG_NAME="molchipv500-armgcc-uclibc"
TOOLS_PKG="`dirname $0`/${PKG_NAME}.tar.bz2"

set +e

mkdir -pv $TOP_DIR
[ $? != 0 ] && exit 1

if [ -d $TOOL_DIR ]
then
	echo "Delete exist directory..." >&2
	rm $TOOL_DIR -rf 
	
fi

echo "Extract cross tools ..." >&2
tar -xjf $TOOLS_PKG -C $TOP_DIR
[ $? != 0 ] && exit 1

pushd $TOP_DIR
mv $PKG_NAME $TOOL_DIR

popd

sed -i  '/\/arm-mol\//d' /etc/profile
[ $? != 0 ] && exit 1

if [ -z "`grep "$TAR_BIN_DIR" < /etc/profile`" ] ;
then
	echo "export path $TAR_BIN_DIR" >&2
	cat >> /etc/profile << EOF

# `date`
# FY Linux, Cross-Toolchain PATH
export PATH="$TAR_BIN_DIR:\$PATH" 
# 

EOF
	[ $? != 0 ] && exit 1
else
	echo "skip export toolchains path" >&2
fi


exit 0
